from django.apps import AppConfig


class FactvisualConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'factvisual'
